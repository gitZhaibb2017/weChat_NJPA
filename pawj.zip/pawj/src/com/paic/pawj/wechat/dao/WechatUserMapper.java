package com.paic.pawj.wechat.dao;

public interface WechatUserMapper {
	
	public WechatUser getUserByOpenid(String openid);

}
