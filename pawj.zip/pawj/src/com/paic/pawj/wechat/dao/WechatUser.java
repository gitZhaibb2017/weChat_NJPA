package com.paic.pawj.wechat.dao;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class WechatUser {

	private String userID;
	
	private String userName;
	
	private String openid;
}
