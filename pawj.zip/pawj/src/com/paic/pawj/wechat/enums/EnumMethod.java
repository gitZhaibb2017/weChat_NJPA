package com.paic.pawj.wechat.enums;

public enum EnumMethod {
	GET,POST;
}
