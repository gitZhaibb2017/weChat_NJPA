package com.paic.ceph.service.impl;

import com.paic.ceph.service.CephService;

//@Service
public class CephServiceImpl implements CephService{

	@Override
	public byte[] getImageData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean transferImageData() {
		// TODO Auto-generated method stub
		return false;
	}

}
