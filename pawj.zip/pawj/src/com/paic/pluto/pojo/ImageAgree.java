package com.paic.pluto.pojo;

public class ImageAgree {

	private String dbid;
	
	private String openId;
	
	private String imgId;
	
//	private String createBy;
//	
//	private Date createDate;
//	
//	private String updateBy;
//	
//	private Date updateDate;

	public String getDbid() {
		return dbid;
	}

	public void setDbid(String dbid) {
		this.dbid = dbid;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getImgId() {
		return imgId;
	}

	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	
}
