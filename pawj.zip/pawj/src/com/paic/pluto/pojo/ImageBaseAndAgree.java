package com.paic.pluto.pojo;

public class ImageBaseAndAgree {

	//图片id
	private String dbid;
	
	private String description;
	
	private String countAgree;
	
	private String countMy;

	public String getDbid() {
		return dbid;
	}

	public void setDbid(String dbid) {
		this.dbid = dbid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCountAgree() {
		return countAgree;
	}

	public void setCountAgree(String countAgree) {
		this.countAgree = countAgree;
	}

	public String getCountMy() {
		return countMy;
	}

	public void setCountMy(String countMy) {
		this.countMy = countMy;
	}
	
	
	
}
