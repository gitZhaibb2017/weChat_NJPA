package com.paic.pluto.service.impl;

public class Test {

	public static void main(String[] args) {
		String str1 = "first_bucket||8BlAZOudNfBtGIHdKXQeLpypcOyZFwWkMDATiMG1eeEEkLOHAv6A7dFILj7tr7P3.jpg";
		String[] str = str1.split("\\|\\|");
		System.out.println(str.length);
		
	}
	
}
