package com.paic.pluto.wechat.util;

public class Constants {
	public static final int AGENTID = 1;
	public static final String CORPID = "wx3bab3576f7554012";
	public static final String ACCESS_TOKEN = "你的企业号_ACCESS_TOKEN";
	public static final String encodingAESKey = "s8vFF4f6AWay3uAdJh79WD6imaam4BV6Kl4eL4UzgfM";
	public static final String SECRET = "e062dea05d1d86f18319d872a44ba252";
	
	public static final String ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";
	
	public static final String STATE = "PAWJ";
}
