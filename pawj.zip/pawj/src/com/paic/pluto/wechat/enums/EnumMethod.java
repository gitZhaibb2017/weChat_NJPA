package com.paic.pluto.wechat.enums;

public enum EnumMethod {
	GET,POST;
}
